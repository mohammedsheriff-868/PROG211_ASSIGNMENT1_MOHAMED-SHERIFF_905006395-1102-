"""Student Record Management System — Limkokwing University, Semester 03."""

class Student:
    """Represent one student using basic, non-sensitive demo data."""
    school_name = "Limkokwing University – Sierra Leone"
    # Optional tuple bonus: fixed example programme choices.
    SUGGESTED_PROGRAMMES = ("Information Technology", "Software Engineering", "Multimedia Technology", "Business Information Technology")

    def __init__(self, student_id, name, programme, level):
        self.student_id = student_id.strip()
        self.name = name.strip()
        self.programme = programme.strip()
        self.level = level.strip()

    def display_details(self):
        """Instance method: display this object's attributes."""
        print(f"Student ID : {self.student_id}")
        print(f"Name       : {self.name}")
        print(f"Programme  : {self.programme}")
        print(f"Level      : {self.level}")
        print(f"Institution: {Student.school_name}")

    @classmethod
    def change_school_name(cls, new_name):
        """Class method: update the shared institution name."""
        new_name = new_name.strip()
        if not new_name:
            return False
        cls.school_name = new_name
        return True


class StudentRecordSystem:
    """Manage Student objects with both a list and a dictionary."""
    def __init__(self):
        self.students = []          # List stores all Student objects.
        self.students_by_id = {}    # Dictionary indexes objects by student ID.

    @staticmethod
    def _key(student_id):
        return student_id.strip().casefold()

    def add_student(self, student):
        key = self._key(student.student_id)
        if not key:
            print("Student ID cannot be empty.")
            return False
        if key in self.students_by_id:
            print("A student with that ID already exists.")
            return False
        self.students.append(student)
        self.students_by_id[key] = student
        print("Student record added successfully.")
        return True

    def find_student(self, student_id):
        return self.students_by_id.get(self._key(student_id))

    def display_all_students(self):
        if not self.students:
            print("No student records are available.")
            return
        print("\n========== STUDENT RECORDS ==========")
        for number, student in enumerate(self.students, start=1):
            print(f"\nRecord {number}")
            print("-" * 35)
            student.display_details()
        print("\nTotal students:", len(self.students))

    def search_student(self, student_id):
        student = self.find_student(student_id)
        if student is None:
            print("No student found with that ID.")
        else:
            print("\nStudent found:")
            print("-" * 35)
            student.display_details()

    def show_summary(self):
        print("\n========== SYSTEM SUMMARY ==========")
        print("Institution:", Student.school_name)
        print("Total student records:", len(self.students))
        print("Suggested programmes (tuple):")
        for programme in Student.SUGGESTED_PROGRAMMES:
            print(" -", programme)


def add_sample_records(system):
    """Create fictional records so the program can be demonstrated immediately."""
    system.add_student(Student("LWK001", "Student One", "Information Technology", "Level 1"))
    system.add_student(Student("LWK002", "Student Two", "Software Engineering", "Level 1"))


def main():
    system = StudentRecordSystem()
    add_sample_records(system)
    while True:
        print("\n======================================")
        print("     STUDENT RECORD MANAGEMENT")
        print("======================================")
        print("1. Add a student")
        print("2. Display all students")
        print("3. Search by student ID")
        print("4. Show system summary")
        print("5. Change institution name (@classmethod demo)")
        print("0. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            student_id = input("Enter student ID: ").strip()
            name = input("Enter student name: ").strip()
            programme = input("Enter programme: ").strip()
            level = input("Enter level/year: ").strip()
            if not all([student_id, name, programme, level]):
                print("All fields are required.")
                continue
            system.add_student(Student(student_id, name, programme, level))
        elif choice == "2":
            system.display_all_students()
        elif choice == "3":
            system.search_student(input("Enter the student ID to search: ").strip())
        elif choice == "4":
            system.show_summary()
        elif choice == "5":
            new_name = input("Enter the new institution name: ").strip()
            if Student.change_school_name(new_name):
                print("Institution name updated.")
            else:
                print("Institution name cannot be empty.")
        elif choice == "0":
            print("Thank you for using the Student Record Management System.")
            break
        else:
            print("Invalid option. Please choose 0, 1, 2, 3, 4, or 5.")

if __name__ == "__main__":
    main()
